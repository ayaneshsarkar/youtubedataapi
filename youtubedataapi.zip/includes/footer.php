  <script src="https://apis.google.com/js/platform.js?onload=init" async defer></script>
  <script src="https://apis.google.com/js/api.js"></script>
  <script src="./js/index.js"></script>
</body>
</html>
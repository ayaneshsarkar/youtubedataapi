<?php

  session_start();

  $json = file_get_contents('php://input');
  $data = json_decode($json);

  $_SESSION['username'] = $data->name;
  $_SESSION['fb_id'] = $data->id;

  echo json_encode([
    'username' => $_SESSION['username'],
    'fb_id' => $_SESSION['fb_id']
  ]);